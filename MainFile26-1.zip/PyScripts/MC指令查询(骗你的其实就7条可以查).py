# coding=utf-8
print("Python3 Script\n\nJava版指令查询,测试版本,不确定是否会持续更新\n输入指令前面代码进行查询\n1_Give\n2_Clear\n3_fill\n4_SetBlock\n5_kill\n6_damage")
st = int(input("输入你要查询的指令节点："));
if st == 1:
    print("\n\n\nGive指令:获取物品\n<目标选择器>+<物品ID>+<NBT数据组件（数据组件查询还未制作，本段可加可不加>+<数量>\n例如/give @s diamond[custom_name:'我是钻石'] 1")
    input("关闭窗口重新运行来查询其他指令")
elif st == 2:
    print("\n\n\nClear指令:移除物品\n<目标选择器>+<物品ID>+<删除数量>\n例如:/clear @s diamond 1")
    input("关闭窗口重新运行来查询其他指令")
elif st == 3:
    print("\n\n\nFill:填充方块\n<整数坐标1（起点）> <整数坐标2（终点）> <方块ID> <状态(非必要)><状态变量(非必要)>\n\n\n状态类型【仅常用状态】: \ndestroy「填充并产生原方块的掉落物」\nhollow「直接填充，没有掉落物」\nreplace+<方块ID>「仅替换对应方块」\n\n\n例如:/fill 1 1 1 9 1 7 air replace oak_planks ")
    input("关闭窗口重新运行来查询其他指令")
elif st == 4:
    print("\n\n\nSetblock:放置方块\n<整数坐标> <方块ID> <状态(非必要)><状态变量(非必要)>\n\n\n状态类型【仅常用状态】: \ndestroy「填充并产生原方块的掉落物」\nreplace+<方块ID>「仅替换对应方块」\n\n\n例如:/setblock 9 1 7 air replace oak_planks ")
    input("关闭窗口重新运行来查询其他指令")
elif st == 5:
    print("\n\n\nkill:杀死对应实体\n<目标选择器> \n\n例如:/kill @e[type=items]")
    input("关闭窗口重新运行来查询其他指令")
elif st == 6:
    print("\n\n\nkill:杀死对应实体\n<目标选择器(仅支持单个目标)> <伤害点数> <伤害类别(若不填写则为普通玩家攻击伤害)>\n\n例如:/damage @s 10 dry_out")
    input("关闭窗口重新运行来查询其他指令")
else:
    input("\n\n\n\n暂不支持\n\n以后可能会更新")