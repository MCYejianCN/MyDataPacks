import os
import json

base = "ResourcePack"

os.makedirs(base, exist_ok=True)
pack_meta = {
    "pack": {
        "description": "ResourcePack\n资源包",
        "pack_format": 121,
        "supported_formats": [121, 121]
    }
}
with open(os.path.join(base, "pack.mcmeta"), "w", encoding="utf-8") as f:
    json.dump(pack_meta, f, ensure_ascii=False, indent=4)

ns_dir = os.path.join(base, "assets", "minecraft", "textures","item")
os.makedirs(ns_dir, exist_ok=True)
ns_dir = os.path.join(base, "assets", "minecraft", "textures","block")
os.makedirs(ns_dir, exist_ok=True)
ns_dir = os.path.join(base, "assets", "minecraft", "textures","gui")
os.makedirs(ns_dir, exist_ok=True)
ns_dir = os.path.join(base, "assets", "minecraft", "textures","entity")
os.makedirs(ns_dir, exist_ok=True)
ns_dir = os.path.join(base, "assets", "minecraft", "textures","ui")
os.makedirs(ns_dir, exist_ok=True)
ns_dir = os.path.join(base, "assets", "minecraft", "sound")
os.makedirs(ns_dir, exist_ok=True)


print("数据包模版创建完成！")
input("按Enter退出...")
