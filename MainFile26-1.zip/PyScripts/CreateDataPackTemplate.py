import os
import json

base = "DataPack"

os.makedirs(base, exist_ok=True)
pack_meta = {
    "pack": {
        "description": "Datapack\n数据包",
        "pack_format": 121,
        "supported_formats": [121, 121]
    }
}
with open(os.path.join(base, "pack.mcmeta"), "w", encoding="utf-8") as f:
    json.dump(pack_meta, f, ensure_ascii=False, indent=4)

ns_dir = os.path.join(base, "data", "yournamespace", "function")
os.makedirs(ns_dir, exist_ok=True)

with open(os.path.join(ns_dir, "main.mcfunction"), "w", encoding="utf-8") as f:
    f.write("# write your datapack!\n")

print("数据包模版创建完成！")
input("按Enter退出...")
