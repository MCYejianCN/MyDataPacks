# coding=utf-8
print("注:满分50分，每题5分\n\n\n")
score = 50
print("1:平原 2:森林 3:恶地 4:滚木")
print("MC最冷门的群系")
str = int(input(""));
if str == 3 :
    input("回答正确，输入键下一题")
else:
    score = score - 5
    input("错误")
print("1:冰山 2:沙漠 3:平原 4:森林")
print("MC最没用的群系")
str = int(input(""));
if str == 1 :
    input("回答正确，输入键下一题")
else:
    score = score - 5
    input("错误")
print("1:刷新生物 2:生成村庄 3:Mojang死在里面 4:钝角")
print("MC中，三个维度都具有的特性")
str = int(input(""));
if str == 1 :
    input("回答正确，输入键下一题")
else:
    score = score - 5
    input("错误")
print("1:主世界 2:末地 3:下界 4:筛界")
print("Mojang最不喜欢的维度(截止于2026年)")
str = int(input(""));
if str == 2 :
    input("回答正确，输入键下一题")
else:
    score = score - 5
    input("错误")
print("1:天境 2:末地 3:主世界 4:没有")
print("Mojang的Bug最多的维度")
str = int(input(""));
if str == 2 :
    input("回答正确，输入键进入双选题,必须两个全对，两个答案直接不需要空格")
else:
    score = score - 5
    input("错误,输入键进入双选题,必须两个全对，两个答案直接不需要空格")
print("1:天境 2:末地 3:主世界 4:筛界")
print("Mojang已经有的两个维度")
str = int(input(""));
if str == 23 :
    input("回答正确，输入键下一题")
else:
    score = score - 5
    input("错误")
print("1:筛界 2:天境 3:没了 4:苏联")
print("Mojang即将推出和没出的>>>维度<<<")
str = int(input(""));
if str == 12 :
    input("回答正确，输入键下一题")
else:
    score = score - 5
    input("错误")
print("下界的特定生物")
print("1:烈焰人 2:凋零骷髅 3:劫掠兽 4:火幻翼")
str = int(input(""));
if str == 12 :
    input("回答正确，输入键下一题")
else:
    score = score - 5
    input("错误")
print("末地不会自然刷新什么生物")
print("1:末影螨 2:村民 3:末影人 4:潜影贝")
str = int(input(""));
if str == 12 :
    input("回答正确，输入键下一题")
else:
    score = score - 5
    input("错误")
print("在玩家的猜测中,末地位于哪里，下界位于哪里")
print("1:Mojang 2:刚毅 3:主世界之下4 :主世界之上")
str = int(input(""));
if str == 34 :
    input("回答正确，输入键下一题")
else:
    score = score - 5
    input("错误")
print("输入键关闭窗口")
print(score,"分")
input("输入键结束")
